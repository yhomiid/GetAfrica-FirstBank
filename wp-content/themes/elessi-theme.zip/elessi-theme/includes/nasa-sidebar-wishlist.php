<div class="widget_shopping_wishlist_content wishlist_sidebar">
    <?php echo shortcode_exists('nasa_yith_wcwl_wishlist') ? do_shortcode('[nasa_yith_wcwl_wishlist]') : '<p class="empty">' . esc_html__('Theme has not been installed or enabled Plugin Yith Wishlist.', 'elessi-theme') . '</p>'; ?>
</div>