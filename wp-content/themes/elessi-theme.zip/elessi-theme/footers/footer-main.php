    </div>
    <!-- MAIN FOOTER -->
    <footer id="nasa-footer" class="footer-wrapper nasa-clear-both">
        <?php do_action('nasa_footer_layout_style'); ?>
    </footer>
    <!-- END MAIN FOOTER -->
</div>
<?php wp_footer(); ?>
</body>
</html>